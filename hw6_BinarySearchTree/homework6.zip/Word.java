import java.util.Set;

public class Word implements Comparable<Word> {
    private String word;
    private Set<Integer> index;
    private int frequency;

    // TODO implement methods below.
}
