import java.util.Comparator;

public class IgnoreCase implements Comparator<Word> {

}
