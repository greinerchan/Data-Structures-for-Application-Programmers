import java.util.ArrayList;
import java.util.Comparator;

public class Index {

    public BST<Word> buildIndex(String fileName) {
        // TODO implement this
    }

    public BST<Word> buildIndex(String fileName, Comparator<Word> comparator) {
        // TODO implement this
    }

    public BST<Word> buildIndex(ArrayList<Word> list, Comparator<Word> comparator) {
        // TODO implement this
    }

    public ArrayList<Word> sortByAlpha(BST<Word> tree) {
        /*
         * Even though there should be no ties with regard to words in BST,
         * in the spirit of using what you wrote, 
         * use AlphaFreq comparator in this method.
         */
        // TODO implement this
    }

    public ArrayList<Word> sortByFrequency(BST<Word> tree) {
        // TODO implement this
    }

    public ArrayList<Word> getHighestFrequency(BST<Word> tree) {
        // TODO implement this
    }

}
