import java.util.Comparator;

public class Frequency implements Comparator<Word> {

}
